package com.example.quark

data class Verification(
    val name: String? = null,
    val village: String? = null,
    val docslink: String? = null,
    val walletaddress: String? = null,
    )
