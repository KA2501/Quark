package com.example.quark

data class userverify(

    val name: String? = null,
    val walletaddress: String? = null,
    val postaladdress: String? = null,
    val docslink: String? = null,
)
