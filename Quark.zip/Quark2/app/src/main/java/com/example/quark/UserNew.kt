package com.example.quark

data class UserNew(
    val name: String? = null,
    val age: String? = null,
    val gender: String? = null,
    val walletaddress: String? = null,
    val postaladdress: String? = null,
    val pincode: String? = null,
)
